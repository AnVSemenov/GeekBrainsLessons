﻿using System;
using System.IO;

namespace SApp04
{
    class Program
    {
        static void Main(string[] args)
        {
            //StaticClass staticClass1 = new StaticClass(new int[20]); // Подобный способ разрешается?
            StaticClass staticClass = new StaticClass(20);

            int[] arr = FileReader(AppDomain.CurrentDomain.BaseDirectory + "TextFile1.txt");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]}\t");
            }
            Console.WriteLine();

            Console.ReadLine();
        }

        public static int[] FileReader(string fileName)
        {
            if (File.Exists(fileName))
            {
                using (StreamReader streamReader = new StreamReader(fileName))
                {
                    int[] buf = new int[1000];
                    int count = 0;

                    while (!streamReader.EndOfStream)
                    {
                        buf[count] = int.Parse(streamReader.ReadLine());
                        count++;
                    }

                    int[] arr = new int[count];

                    Array.Copy(buf, arr, count);

                    return arr;
                    
                }
            }
            else
            {
                throw new FileNotFoundException();
            }

        }
    }

    class StaticClass
    {
        int[] mass;

        public StaticClass(int[] mass) 
        {
            this.mass = mass;
        }

        public StaticClass(int number)
        {
            mass = new int[number];
            int counter = 0;
            Random random = new Random();
            
            for (int i = 0; i < mass.Length; i++)
            {
                int num = random.Next(-10000, 10001);
                mass[i] = num;
            }

            for (int i = 0; i < mass.Length; i++)
            {
                if(i == mass.Length - 1)
                {
                    continue;
                }
                else
                {
                    if (mass[i] % 3 == 0)
                    {
                        if(mass[i + 1] % 3 != 0)
                        {
                            counter++;
                        }
                    }
                    else
                    {
                        if (mass[i + 1] % 3 == 0)
                        {
                            counter++;
                        }
                    }
                }
            }

            Console.WriteLine(counter);
        }
    }
}
