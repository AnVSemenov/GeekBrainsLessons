﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SApp01
{
    // Прошу прощения за позднюю отправку дз.

    class Program
    {
        static void Main(string[] args)
        {
            
            #region Задание 1
            Console.WriteLine("///Первое задание///");
            Console.WriteLine("");

            Console.WriteLine("Введите ваше имя:");
            string name = Console.ReadLine();
            Console.WriteLine("Введите вашу фамилию:");
            string surname = Console.ReadLine();
            Console.WriteLine("Введите ваш возраст:");
            string age = Console.ReadLine();
            Console.WriteLine("Введите ваш рост, см:");
            int height = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите ваш вес, кг:");
            int weight = int.Parse(Console.ReadLine());
            Console.WriteLine($"Ваши данные: {name} {surname}, {age} лет, {height} см, {weight} кг.");
           
            Console.WriteLine("");
            #endregion

            #region Задание 2
            Console.WriteLine("///Второе задание///");
            Console.WriteLine("");
            Console.WriteLine($"Ваш ИМТ: " + (double)height/(weight * weight)); // подсмотрел про (double)... тут https://docs.microsoft.com/ru-ru/dotnet/csharp/language-reference/operators/arithmetic-operators#division-operator-
            
            Console.WriteLine("");
            #endregion

            #region Задание 3
            Console.WriteLine("///Третье задание///");
            Console.WriteLine("");

            double x1 = 156;
            double x2 = 334;
            double y1 = 11;
            double y2 = 256;

            double r = MathMethod(x1, x2, y1, y2);
            Console.WriteLine(r); // Не понял, как задать .2f значению переменной. Подскажите, пожалуйста. 

            Console.WriteLine("");
            #endregion

            #region Задание 4

            Console.WriteLine("///Четвертое задание///");
            Console.WriteLine("");
            Console.WriteLine("Введите значение a:");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Введите значение b:");
            int b = int.Parse(Console.ReadLine());
            
            int c = a;
            a = b;
            b = c;

            Console.WriteLine($"Обычный способ: a = {a}, b = {b}");


            // Не понял, как сделать это без "методов" и относится ли список к ним(глупый)
            List<int> list = new List<int>();
            list.Add(a);
            list.Add(b);

            a = list[1];
            b = list[0];

            Console.WriteLine($"Странный способ: a = {b}, b = {a}");

            Console.WriteLine("");
            #endregion

            #region Задание 5
            Console.WriteLine("///Пятое задание///");
            Console.WriteLine("");

            Console.WriteLine("Введите ваш город проживания:");
            string city = Console.ReadLine();

            string str = name + " " + surname + " из города " + city;
            PrintQuest5(str, 50, 36);

            Console.WriteLine("");
            #endregion

            Console.ReadLine();
        }

        static double MathMethod(double x1, double x2, double y1, double y2)
        {
            double r = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

            return r;
        }

        static void PrintQuest5(string str, int x, int y)
        {
            Console.SetCursorPosition(x, y);
            Console.WriteLine(str);
        }
    }

    #region Задание 6
    class HelpInLesson
    {
        void Pause()
        {
            Console.ReadLine();
        }

        void Print(string str)
        {
            Console.WriteLine(str);
        }
    }
    #endregion
}
