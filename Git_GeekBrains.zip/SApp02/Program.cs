﻿using System;

namespace SApp02
{
    class Program
    {
        static int sum = 0;

        static void Main(string[] args)
        {
            Menu();
            Console.ReadLine();
        }

        static void Menu()
        {
            int number = 1;
            while (number != 0)
            {
                Console.Write("Выберите задание от 1 до 7: ");

                number = int.Parse(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        Console.WriteLine("Минимальное число: " + Quest1());
                        Console.WriteLine("");
                        break;
                    case 2:
                        Console.WriteLine("Количество чисел: " + Quest2());
                        Console.WriteLine("");
                        break;
                    case 3:
                        Console.WriteLine("Количество нечетных чисел: " + Quest3());
                        Console.WriteLine("");
                        break;
                    case 4:
                        Console.WriteLine(Quest4());
                        Console.WriteLine("");
                        break;
                    case 5:
                        Console.WriteLine(Quest5());
                        Console.WriteLine("");
                        break;
                    case 6:
                        Console.WriteLine("Количество хороших чисел: " + Quest6());
                        Console.WriteLine("");
                        break;
                    case 7:
                        Quest7(1);
                        Console.WriteLine($"Сумма всех чисел: {sum}");
                        Console.WriteLine("");
                        break;
                    case 0:
                        Console.Write("Выход из программы.");
                        break;
                    default: 
                        Console.WriteLine("Такого задания нет.");
                        Console.WriteLine("");
                        break;
                }
            }
        }

        static int Quest1()
        {
            Console.WriteLine("Введите 3 числа:");
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());

            int result = num1 < num2 ? (num1 < num3 ? num1 : num3) : (num2 < num3 ? num2 : num3);

            return result;
        }

        static int Quest2()
        {
            Console.Write("Введите число любой длинны: ");
            string str = Console.ReadLine();
            
            
            return str.Length;
        }

        static int Quest3()
        {
            Console.WriteLine("Введите числа, 0 будет выходом: ");

            int number = 1;
            int counter = 0;

            while (number != 0) 
            {
                number = int.Parse(Console.ReadLine());
                if(number > 0 && (number % 2 > 0))
                {
                    counter++;
                }
            }

            return counter;
        }

        static string Quest4()
        {
            Console.WriteLine("Введите логин и пароль для входа: ");
            string login;
            string password;
            int counter = 0;
            bool pass = true;

            do
            {
                counter++;
                if (counter == 4)
                {
                    pass = false;
                    break;
                }

                Console.Write("Логин: ");
                login = Console.ReadLine();
                Console.Write("Пароль: ");
                password = Console.ReadLine();
            }
            while (login != "root" & password != "GeekBrains");

            if (pass) 
            {
                return "Вы прошли!";
            }
            else 
            { 
                return "Конец попыток для входа!"; 
            };
        }

        static string Quest5()
        {
            Console.Write("Введите ваш рост: ");
            double height = int.Parse(Console.ReadLine());
            Console.Write("Введите вашу массу: ");
            double weight = double.Parse(Console.ReadLine());
            double index = weight / Math.Pow(height / 100, 2);

            double indexMin = 18.5;
            double indexMax = 25;

            double MinWeight = indexMin * Math.Pow(height / 100, 2); // вычисляем Минимльный вес по росту и классификации массы тела
            double MaxWeight = indexMax * Math.Pow(height / 100, 2); // Вычисляем Иаксимальный вес по росту и классификации массы тела
            double RecomWeight = (MaxWeight + MinWeight) / 2; // Вычисляем оптимальный вес

            string textResult;

            if (index > indexMax)
            {
                textResult = $"Ваш вес выше рекомендуемого! Индекс тела составляет {index:F2}, желательно сбросить {weight - MaxWeight:F2} кг для рекомендуемого максимума или {weight - RecomWeight:F2} кг для оптимального веса.";
            }
            else if (index < indexMin)
            {
                textResult = $"Ваш вес ниже рекомендуемого! Индекс тела составляет {index:F2}, желательно набрать {MinWeight - weight:F2} кг для рекомендуемого минимума или {RecomWeight - weight:F2} кг для оптимального веса.";
            }
            else
            {
                textResult = $"Ваш вес в средних значениях! Индекс тела составляет {index:F2}."; 
            }

            return textResult;
        }

        static int Quest6()
        {
            DateTime dateTime = DateTime.Now;
            Console.WriteLine($"Начало выполнения: {dateTime}");
            
            int counter = 0;
            int number = 0;
            
            for (int i = 1; i <= 10000000; i++)
            {
                string s = i.ToString();

                foreach (char sNum in s) 
                {
                    string str = sNum.ToString();
                    int num = int.Parse(str);
                    number += num;
                }

                if(i % number == 0)
                {
                    counter += 1;
                }
                 
                number = 0;
            }

            Console.WriteLine($"Время выполнения: {DateTime.Now - dateTime}");

            return counter;
        }

        static void Quest7(int a)
        {
            int b = 11;
            
            Console.WriteLine(a);
            if (a < b)
            {
                Quest7(a + 1);
            }
            sum += a;
        }
    }
}
