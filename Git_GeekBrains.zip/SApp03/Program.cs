﻿using System;

namespace SApp03
{
    class Complex
    {
        private double re;
        private double im;

        public Complex(double re, double im)
        {
            this.re = re;
            this.im = im;
        }

        public Complex Pr(Complex x)
        {
            Complex y = new Complex(re * x.re, im * x.im);
            return y;
        }

        public Complex Minus(Complex x)
        {
            return new Complex(re - x.re, im - x.im);
        }

        public override string ToString()
        {
            return $"({re} + {im}i)";
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Задание 1.");
            Console.WriteLine("");
            Complex complex01 = new Complex(3, 2);
            Console.WriteLine(complex01);
            Complex complex02 = new Complex(5, 6);
            Console.WriteLine(complex02);

            Console.WriteLine("Введите - для вычитания или * для произведения");
            switch (Console.ReadLine())
            {
                case "-":
                    Console.WriteLine("Вычитание в class:  " + complex01.ToString() + " - " + complex02.ToString() + " = " + complex01.Minus(complex02));
                    break;
                case "*":
                    Console.WriteLine("Произведение в class: " + complex01.ToString() + " * " + complex02.ToString() + " = " + complex01.Pr(complex02));
                    break;
                default:
                    Console.WriteLine("Ошибка, пропуск работы с class.");
                    break;
            }
            Console.WriteLine("");

            ComplexStruct complexStruct;
            complexStruct.re = 7;
            complexStruct.im = 1;
            Console.WriteLine(complexStruct);

            ComplexStruct complexStruct2;
            complexStruct2.re = 4;
            complexStruct2.im = 11;
            Console.WriteLine(complexStruct2);

            Console.WriteLine("Вычитание в struct: " + complexStruct + " - " + complexStruct2 + " = " + complexStruct.Minus(complexStruct2));
            Console.WriteLine("");

            Console.WriteLine("Задание 2.");
            Console.WriteLine("");

            Console.WriteLine("Введите числа, 0 будет выходом: ");

            int number = 1;
            int numbers = 0;

            while (number != 0)
            {
                if(int.TryParse(Console.ReadLine(), out number))
                {
                    if (number > 0 && (number % 2 > 0))
                    {
                        numbers += number;
                    }
                }
            }

            Console.WriteLine(numbers);
        }
    }

    struct ComplexStruct
    {
        public double re;
        public double im;

        public ComplexStruct Minus(ComplexStruct x)
        {
            return new ComplexStruct(re - x.re, im - x.im);
        }

        public override string ToString()
        {
            return $"({re} + {im}i)";
        }

        public ComplexStruct(double re, double im)
        {
            this.re = re;
            this.im = im;
        }

    }
}
