﻿using System;

namespace SApp02
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu();
            Console.ReadLine();
        }

        static void Menu()
        {
            int number = 1;
            while (number != 0)
            {
                Console.Write("Выберите задание от 1 до 7:");

                number = int.Parse(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        Console.WriteLine(Quest1());
                        Console.WriteLine("");
                        break;
                    case 2:
                        Console.WriteLine(Quest2());
                        Console.WriteLine("");
                        break;
                    case 3:
                        Console.WriteLine("Количество нечетных чисел: " + Quest3());
                        Console.WriteLine("");
                        break;
                    case 4:
                        Console.WriteLine(Quest4());
                        Console.WriteLine("");
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                    case 7:
                        break;
                    default:
                        break;
                }
            }
            
        }

        static int Quest1()
        {
            Console.WriteLine("Введите 3 числа:");
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            int num3 = int.Parse(Console.ReadLine());

            int result = num1 < num2 ? (num1 < num3 ? num1 : num3) : (num2 < num3 ? num2 : num3);

            return result;
        }

        static int Quest2()
        {
            Console.Write("Введите число любой длинны: ");
            string str = Console.ReadLine();
            
            
            return str.Length;
        }

        static int Quest3()
        {
            Console.WriteLine("Введите числа, 0 будет выходом: ");

            int number = 1;
            int counter = 0;

            while (number != 0) 
            {
                number = int.Parse(Console.ReadLine());
                if(number > 0 && (number % 2 > 0))
                {
                    counter++;
                }
            }

            return counter;
        }

        static string Quest4()
        {
            Console.WriteLine("Введите логин и пароль для входа: ");
            string login = "";
            string password = "";
            int counter = 0;
            bool pass = true;

            do
            {
                if (counter < 3) 
                {
                    Console.Write("Логин: ");
                    login = Console.ReadLine();
                    Console.Write("Пароль: ");
                    password = Console.ReadLine();
                    counter++;
                }
                else
                {
                    pass = false;
                    break;
                }
            }
            while (login != "root" & password != "GeekBrains");

            if (pass) 
            {
                return "Вы прошли!";
            }
            else 
            { 
                return "Конец попыток для входа!"; 
            };
        }
    }
}
